This example shows how to sign/verify an XML document using OMXMLSecurity.

SYNTAX: ./sign <input-xml-file> <operation [S/V]> <certificate> <key>
e.g. 
TO SIGN %./sign input.xml S cert.pem key.pem
TO VERIFY %s./sign result-sign.xml V


