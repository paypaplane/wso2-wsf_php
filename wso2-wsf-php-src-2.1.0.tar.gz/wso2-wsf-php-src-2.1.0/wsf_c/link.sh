#!/bin/bash
mkdir -p mkdir /etc/opt/wso2/wsf_c
ln -f -s $1/axis2.xml /etc/opt/wso2/wsf_c/axis2.xml




