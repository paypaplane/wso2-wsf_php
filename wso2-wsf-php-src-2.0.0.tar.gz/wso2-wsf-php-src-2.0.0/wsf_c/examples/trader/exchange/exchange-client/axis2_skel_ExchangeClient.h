

    /**
     * axis2_skel_ExchangeClient.h
     *
     * This file was auto-generated from WSDL for "ExchangeClient|http://www.wso2.org" service
     * by the Apache Axis2/C version: #axisVersion# #today#
     * axis2_skel_ExchangeClient Axis2/C skeleton for the axisService- Header file
     */


	#include <axis2_svc_skeleton.h>
	#include <axutil_log_default.h>
	#include <axutil_error_default.h>
	#include <axiom_text.h>
	#include <axiom_node.h>
	#include <axiom_element.h>
    #include <stdio.h>


   
     #include  "axis2_getInfoResponse.h"
    
     #include "axis2_getInfoRequest.h"
    

		 
        /**
         * auto generated function declaration
         * for "getInfo|http://www.wso2.org" operation.
         
         * @param getInfoRequest
         */
        axis2_getInfoResponse_t* axis2_skel_ExchangeClient_getInfo (const axutil_env_t *env  ,
                                          axis2_getInfoRequest_t* getInfoRequest );
     

