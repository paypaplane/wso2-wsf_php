

    /**
     * axis2_skel_ExchangeClient.c
     *
     * This file was auto-generated from WSDL for "ExchangeClient|http://www.wso2.org" service
     * by the Apache Axis2/C version: #axisVersion# #today#
     * axis2_skel_ExchangeClient Axis2/C skeleton for the axisService
     */

     #include "axis2_skel_ExchangeClient.h"

     

		 
        /**
         * auto generated function definition signature
         * for "getInfo|http://www.wso2.org" operation.
         
         * @param getInfoRequest
         */
        axis2_getInfoResponse_t* axis2_skel_ExchangeClient_getInfo (const axutil_env_t *env  ,
                                              axis2_getInfoRequest_t* getInfoRequest )
        {
          /* TODO fill this with the necessary business logic */
          return NULL;
        }
     

