

    /**
     * axis2_skel_TraderExchange.h
     *
     * This file was auto-generated from WSDL for "TraderExchange|http://www.wso2.org" service
     * by the Apache Axis2/C version: #axisVersion# #today#
     * axis2_skel_TraderExchange Axis2/C skeleton for the axisService- Header file
     */


	#include <axis2_svc_skeleton.h>
	#include <axutil_log_default.h>
	#include <axutil_error_default.h>
	#include <axiom_text.h>
	#include <axiom_node.h>
	#include <axiom_element.h>
    #include <stdio.h>


   
     #include "axis2_updateRequest.h"
    

		 
        /**
         * auto generated function declaration
         * for "update|http://www.wso2.org" operation.
         
         * @param updateRequest
         */
        axis2_status_t  axis2_skel_TraderExchange_update (const axutil_env_t *env  ,
                                          axis2_updateRequest_t* updateRequest );
     

