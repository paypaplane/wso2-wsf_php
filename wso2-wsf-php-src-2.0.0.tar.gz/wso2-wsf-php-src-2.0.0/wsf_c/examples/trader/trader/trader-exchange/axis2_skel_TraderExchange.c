

    /**
     * axis2_skel_TraderExchange.c
     *
     * This file was auto-generated from WSDL for "TraderExchange|http://www.wso2.org" service
     * by the Apache Axis2/C version: #axisVersion# #today#
     * axis2_skel_TraderExchange Axis2/C skeleton for the axisService
     */

     #include "axis2_skel_TraderExchange.h"

     

		 
        /**
         * auto generated function definition signature
         * for "update|http://www.wso2.org" operation.
         
         * @param updateRequest
         */
        axis2_status_t  axis2_skel_TraderExchange_update (const axutil_env_t *env  ,
                                              axis2_updateRequest_t* updateRequest )
        {
          /* TODO fill this with the necessary business logic */
          return AXIS2_SUCCESS;
        }
     

